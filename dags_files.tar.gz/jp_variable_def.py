from airflow import DAG
from airflow.decorators import task
from airflow.sdk import Variable
from datetime import datetime, timedelta

with DAG(
    dag_id="jp_variable_usage",
    start_date=datetime.now() - timedelta(days=1),
    schedule=None,
    catchup=False,
    tags=["example"],
) as dag:

    @task
    def greet():
        # Fetch variable from Airflow
        name = Variable.get("my_name", default="Guest")
        print(f"Hello, {name}!")

    greet()

