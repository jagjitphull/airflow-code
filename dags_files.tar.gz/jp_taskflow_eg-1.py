from airflow.decorators import dag, task
from datetime import datetime

@dag(
    schedule=None,   # or set a cron schedule
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['jp_taskflow_example', 'taskflow'],
)
def simple_taskflow_dag():

    @task
    def get_numbers():
        return [1, 2, 3, 4, 5]

    @task
    def double_numbers(numbers: list):
        return [n * 2 for n in numbers]

    @task
    def print_result(numbers: list):
        print(f"Final numbers: {numbers}")

    # Define the flow
    nums = get_numbers()
    doubled = double_numbers(nums)
    print_result(doubled)

dag = simple_taskflow_dag()
