from airflow.decorators import dag, task
from datetime import datetime, timedelta
from airflow.utils.trigger_rule import TriggerRule

@dag(
    schedule="@daily",
    start_date=datetime.now() - timedelta(days=1),  # start_date is yesterday
    catchup=False,
    tags=["example", "branching"],
)
def jp_branch_example_decorator():
    # Branching task
    @task.branch
    def choose_path(condition: str):
        if condition == "A":
            return "task_a"
        else:
            return "task_b"

    @task
    def task_a():
        print("Path A chosen!")

    @task
    def task_b():
        print("Path B chosen!")

    @task(trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
    def after_branch():
        print("After branching.")

    # Task pipeline
    chosen = choose_path("B")
    a = task_a()
    b = task_b()
    after = after_branch()

    chosen >> [a, b] >> after

# Instantiate the DAG for Airflow to detect
dag = jp_branch_example_decorator()

