#downstream_dag.py

import pendulum
from airflow.sdk import DAG
from airflow.providers.standard.operators.bash import BashOperator
from airflow.sensors.external_task import ExternalTaskSensor

with DAG(

    dag_id="jp_downstream_dag",
    start_date=pendulum.datetime(2024, 1, 1, tz="UTC"),
    schedule="@daily",
    catchup=False,
    tags=["jp_downstream"],
) as dag:

    wait_for_upstream = ExternalTaskSensor(
        task_id="wait_for_upstream_task",
        external_dag_id="upstream_dag",
        external_task_id="generate_data",
        mode="poke",  # or "reschedule" for efficiency
        timeout=600,  # 10 minutes
        poke_interval=30,
    )

    run_downstream_task = BashOperator(
        task_id="do_something_after_upstream",
        bash_command="echo 'Running after upstream DAG is done.'"
    )

    wait_for_upstream >> run_downstream_task
