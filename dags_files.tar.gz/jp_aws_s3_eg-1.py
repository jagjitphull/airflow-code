from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

import os
from datetime import datetime, timedelta

# CONFIGURATION
#LOCAL_DATA_DIR = '/home/jilg/airflow_learning/data/uploads/'
LOCAL_DATA_DIR = '/tmp/data/uploads/'
LOCAL_ARCHIVE_DIR = '/tmp/data/uploads/archive/'
S3_BUCKET = 'jpairflow-2025-07-08'
S3_PREFIX = 'uploads/'  # Folder inside bucket

def upload_files_to_s3():
    s3 = S3Hook(aws_conn_id='aws_default')
    if not os.path.exists(LOCAL_ARCHIVE_DIR):
        os.makedirs(LOCAL_ARCHIVE_DIR)

    files = [f for f in os.listdir(LOCAL_DATA_DIR) if os.path.isfile(os.path.join(LOCAL_DATA_DIR, f))]
    for filename in files:
        local_path = os.path.join(LOCAL_DATA_DIR, filename)
        s3_key = S3_PREFIX + filename
        s3.load_file(
            filename=local_path,
            key=s3_key,
            bucket_name=S3_BUCKET,
            replace=True
        )
        # Move uploaded file to archive
        os.rename(local_path, os.path.join(LOCAL_ARCHIVE_DIR, filename))
        print(f"Uploaded {filename} to s3://{S3_BUCKET}/{s3_key}")

with DAG(
    dag_id='jp_local_to_s3_upload',
    description='Upload local files to S3 and archive them',
    schedule='0 18 * * *',  # Every day at 6:00 PM
    start_date=datetime(2024, 1, 1),
    catchup=False,
    default_args={'retries': 1, 'retry_delay': timedelta(minutes=5)}
) as dag:

    upload_task = PythonOperator(
        task_id='upload_files_to_s3',
        python_callable=upload_files_to_s3,
    )

    upload_task
