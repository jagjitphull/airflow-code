from __future__ import annotations

import pendulum

from airflow.models.dag import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="jp_data_interval_example",
    start_date=pendulum.datetime(2025, 7, 12, tz="UTC"),
    schedule="@daily", # daily schedule
    #schedule=None, # no schedule
    catchup=False,
    tags=["jp_data_interval_eg"],
) as dag:
    print_data_interval = BashOperator(
        task_id="print_data_interval",
        bash_command=(
            "echo 'Data Interval Start: {{ data_interval_start }}'"
            "echo 'Data Interval End: {{ data_interval_end }}'"
            "echo 'Traditional DS: {{ ds }}'"
            #"echo 'Traditional Execution Date: {{ execution_date }}'" # Still available for compatibility
        ),
    )

# If run for 2025-07-12:
# data_interval_start: 2025-07-11 00:00:00+00:00
# data_interval_end:   2025-07-12 00:00:00+00:00
# ds: 2025-07-11
# execution_date: 2025-07-11T00:00:00+00:00
