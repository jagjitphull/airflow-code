from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.timezone import datetime
from datetime import timedelta

# Define a function to simulate incremental data processing
def process_incremental_data(**context):
    start_date = context['data_interval_start']
    end_date = context['data_interval_end']
    
    # Simulate fetching data within the interval (dummy data)
    print(f"Processing data from {start_date} to {end_date}")

    # Example dummy data processing
    dummy_data = [f"Record {i}" for i in range(1, 6)]
    for record in dummy_data:
        print(f"{record}: processed for interval {start_date.date()} to {end_date.date()}")

# DAG definition
with DAG(
    dag_id='jp_incremental_processing_example',
    start_date=datetime(2024, 7, 1),
    schedule='@daily',  # daily incremental processing
    catchup=True,       # ensure DAG runs incrementally from start_date
    default_args={
        'owner': 'airflow',
        'retries': 1,
        'retry_delay': timedelta(minutes=5)
    },
    tags=['incremental', 'example'],
) as dag:

    incremental_task = PythonOperator(
        task_id='incremental_task',
        python_callable=process_incremental_data,
    )

    incremental_task

