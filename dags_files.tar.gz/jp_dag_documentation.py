from airflow import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime

with DAG(
    dag_id="jp_dag_doc_example",
    start_date=datetime(2024, 7, 1),
    schedule="@daily",
    catchup=False,
    tags=["doc", "example"],
    doc_md="""
# Example DAG Documentation

This DAG is an example of how to add documentation in **Markdown**.

- You can use bullet points
- Add code: `print('Hello Airflow!')`
- Use headers, links, and more.

For details, see the [Airflow documentation](https://airflow.apache.org/docs/).
"""
) as dag:
    task1 = EmptyOperator(task_id="task1")
    task2 = EmptyOperator(task_id="task2")
    task1 >> task2

