from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.latest_only import LatestOnlyOperator
from datetime import datetime, timedelta

with DAG(
    dag_id="jp_latest_only_example",
    start_date=datetime.now() - timedelta(days=2),
    schedule="@daily",
    catchup=True,  # Enable backfill to see the operator's effect
    tags=["example", "latestonly"],
) as dag:

    start = EmptyOperator(task_id="start")

    # Only runs on the latest DAG Run (not on backfills)
    latest_only = LatestOnlyOperator(task_id="only_latest")

    # Downstream tasks
    task1 = EmptyOperator(task_id="task1")
    task2 = EmptyOperator(task_id="task2")

    start >> latest_only >> [task1, task2]

