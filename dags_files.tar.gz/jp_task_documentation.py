from airflow import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime

with DAG(
    dag_id="jp_task_doc_example",
    start_date=datetime(2024, 7, 1),
    schedule="@daily",
    catchup=False,
    tags=["doc", "example"],
) as dag:
    start = EmptyOperator(task_id="start")
    process = EmptyOperator(task_id="process")
    end = EmptyOperator(task_id="end")

    # Add documentation to tasks
    start.doc_md = """
**Start Task**

This task marks the beginning of the workflow.
"""

    process.doc_md = """
**Process Task**

This task processes the main data.  
You can include:
- *Markdown*
- Code examples
- Tables

| Step | Description      |
|------|------------------|
| 1    | Initial process  |
| 2    | Further process  |
"""

    end.doc_md = """
**End Task**

The workflow finishes here.
"""

    start >> process >> end

