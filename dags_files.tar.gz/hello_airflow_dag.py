from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG(
    dag_id="jp_hello_airflow",
    start_date=datetime(2024, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["example"]
) as dag:

    task_1 = BashOperator(
        task_id="print_hello",
        bash_command="echo 'Hello from Airflow!,JP'")

    task_2 = BashOperator(
        task_id="print_date",
        bash_command="date"
    )

    task_1 >> task_2

