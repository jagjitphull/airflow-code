from airflow.decorators import dag, setup, teardown, task
from datetime import datetime

@dag(
    start_date=datetime(2024, 7, 1),
    schedule="@daily",
    catchup=False,
    tags=["example", "decorators"],
)
def jp_setup_teardown_decorator_example():

    @setup
    def prepare():
        print("Setup: preparing resources!")

    @task
    def main_task_1():
        print("Doing main task 1...")

    @task
    def main_task_2():
        print("Doing main task 2...")

    @teardown
    def cleanup():
        print("Teardown: cleaning up resources!")

    # Workflow: setup -> (main tasks) -> teardown
    prepare() >> [main_task_1(), main_task_2()] >> cleanup()

dag = jp_setup_teardown_decorator_example()

