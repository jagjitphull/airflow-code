from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

def extract():
    return [10, 20, 30]

def transform(ti):
    data = ti.xcom_pull(task_ids='extract')
    return [x * 2 for x in data]

def load(ti):
    data = ti.xcom_pull(task_ids='transform')
    print(f"Loading data: {data}")

with DAG("jp_mini_etl", start_date=datetime(2024, 1, 1), schedule=None, catchup=False) as dag:
    extract = PythonOperator(task_id="extract", python_callable=extract)
    transform = PythonOperator(task_id="transform", python_callable=transform)
    load = PythonOperator(task_id="load", python_callable=load)

    extract >> transform >> load
