from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.utils.edgemodifier import Label
from datetime import datetime

with DAG(
    dag_id="jp_edge_label_simple_example",
    schedule="@daily",
    start_date=datetime(2024, 7, 1),
    catchup=False,
    tags=["jpsimple","example", "edgelabel"],
) as dag:
    start = EmptyOperator(task_id="start")
    quality_check = EmptyOperator(task_id="quality_check")
    pass_step = EmptyOperator(task_id="pass")
    fail_step = EmptyOperator(task_id="fail")
    end = EmptyOperator(task_id="end")

    start >> quality_check
    quality_check >> Label("passed") >> pass_step >> end
    quality_check >> Label("failed") >> fail_step >> end

