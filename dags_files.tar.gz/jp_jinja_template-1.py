from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG(
    dag_id="jp_jinja_template_example",
    start_date=datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
    tags=["example"],
) as dag:

    print_context = BashOperator(
        task_id="print_context",
        bash_command="echo 'Run date is {{ ds }}'",
    )

    print_custom_value = BashOperator(
        task_id="print_custom",
        bash_command="echo 'Hello {{ dag_run.conf.get(\"name\", \"Airflow User\") }}!'",
    )

    print_context >> print_custom_value

