from airflow import DAG
from airflow.operators.email import EmailOperator
from datetime import datetime

with DAG(
    dag_id="jp_docker_email_gmail_test",
    schedule=None,
    start_date=datetime(2024, 1, 1),
    catchup=False,
) as dag:
    send_email = EmailOperator(
        task_id='send_email',
        to='alerterneo@gmail.com',
        subject='Test Email from Airflow Docker',
        html_content='This is a test from Airflow Docker Compose!',
    )

