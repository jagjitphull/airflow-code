from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

# Example list of filenames (could come from anywhere)
file_list = ['file_a.csv', 'file_b.csv', 'file_c.csv']

def process_file(filename):
    print(f"Processing {filename}")

with DAG(
    dag_id="jp_dynamic_task_example",
    start_date=datetime(2024, 7, 1),
    schedule="@daily",
    catchup=False,
    tags=["dynamic", "example"],
) as dag:

    # Dynamically create a task for each file
    for fname in file_list:
        PythonOperator(
            task_id=f"process_{fname.replace('.', '_')}",
            python_callable=process_file,
            op_args=[fname],
        )

