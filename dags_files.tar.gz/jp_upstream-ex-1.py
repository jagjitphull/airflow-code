#upstream_dag.py

import pendulum
from airflow.sdk import DAG
from airflow.providers.standard.operators.bash import BashOperator

with DAG(
    dag_id="jP_upstream_dag",
    start_date=pendulum.datetime(2024, 1, 1, tz="UTC"),
    schedule="@daily",
    catchup=False,
    tags=["jp_upstream"],
) as dag:

    task_a = BashOperator(
        task_id="generate_data",
        bash_command="echo 'Data generated!'"
    )

