from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG(
    'jp_example_executor_dag',
    start_date=datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
) as dag:
    t1 = BashOperator(
        task_id='task1',
        bash_command='echo "Task 1 running"'
    )
    t2 = BashOperator(
        task_id='task2',
        bash_command='echo "Task 2 running"'
    )
    t3 = BashOperator(
        task_id='task3',
        bash_command='echo "Task 3 running"'
    )
