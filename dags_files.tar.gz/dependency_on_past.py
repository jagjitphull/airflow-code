from airflow import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime, timedelta

with DAG(
    dag_id="jp_depends_on_past_example",
    start_date=datetime(2024, 7, 1),
    schedule="@daily",
    catchup=True
) as dag:

    t1 = EmptyOperator(
        task_id="t1",
        depends_on_past=True  # This is the key!
    )

