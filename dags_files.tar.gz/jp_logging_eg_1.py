from airflow.decorators import dag, task
from datetime import datetime
import logging

@dag(
    schedule=None,
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['logging-example'],
)
def logging_taskflow_dag():

    @task
    def process_numbers():
        logger = logging.getLogger("airflow.task")
        logger.info("Starting number processing task.")

        numbers = [10, 20, 30]
        logger.info(f"Numbers to process: {numbers}")

        processed = [n * 2 for n in numbers]
        logger.info(f"Processed numbers: {processed}")

        logger.info("Finished processing numbers.")
        return processed

    process_numbers()

dag = logging_taskflow_dag()

