from airflow import DAG
from airflow.sensors.filesystem import FileSensor
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG(
    dag_id="jp_file_sensor_example",
    start_date=datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
    tags=["example"],
) as dag:

    wait_for_file = FileSensor(
        task_id="wait_for_file",
        filepath="/tmp/trigger.txt",
        fs_conn_id="fs_default",
        poke_interval=15,        # Check every 30 seconds
        timeout=600,             # Fail if not found in 10 minutes
        #mode="reschedule",       # Efficient mode (no worker slot held between checks)
        mode="poke",       # Efficient mode (no worker slot held between checks)
    )

    process_file = BashOperator(
        task_id="process_file",
        bash_command="echo 'File found! Processing...'",
    )

    wait_for_file >> process_file

