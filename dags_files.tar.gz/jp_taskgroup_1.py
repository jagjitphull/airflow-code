from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.utils.task_group import TaskGroup
from datetime import datetime

with DAG(
    dag_id="jp_taskgroup_example",
    start_date=datetime(2024, 7, 1),
    schedule="@daily",   # New style for Airflow 3.x
    catchup=False,
    tags=["example", "taskgroup"],
) as dag:

    start = EmptyOperator(task_id="start")

    # Define a TaskGroup
    with TaskGroup("processing_group") as processing_group:
        task1 = EmptyOperator(task_id="task1")
        task2 = EmptyOperator(task_id="task2")
        task3 = EmptyOperator(task_id="task3")
        task1 >> task2 >> task3

    end = EmptyOperator(task_id="end")

    # Set dependencies: start -> processing_group -> end
    start >> processing_group >> end

